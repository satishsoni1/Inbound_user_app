
var krms_config ={	
	'ApiUrl' : "http://ec2-13-126-171-124.ap-south-1.compute.amazonaws.com/kmrs/mobileapp/api",
	'ApiUrl2' : "http://ec2-13-126-171-124.ap-south-1.compute.amazonaws.com/Inbound_Project/webservice",
	'DialogDefaultTitle' : "Inbound",
	'pushNotificationSenderid' : "281792327024",
	'facebookAppId' : "299608633836956",
	'APIHasKey' : ""
};